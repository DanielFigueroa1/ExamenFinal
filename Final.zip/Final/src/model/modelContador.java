package model;

import processing.core.PApplet;

public class modelContador extends PApplet {

}
