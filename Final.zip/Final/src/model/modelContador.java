package model;

public class modelContador {

}
