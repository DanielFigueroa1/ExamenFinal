package model;

import java.util.ArrayList;

import processing.core.PApplet;

public class modelLogica implements Runnable {

	private PApplet app;
	private ArrayList<modelPersona> personas;
	String[] datos;
	
	public modelLogica(PApplet app) {
		this.app = app;
		personas = new ArrayList<modelPersona>();
		
		String[] datos = app.loadStrings("datos.txt");
		String[] sanos = datos[0].split(":",2);
		int nSanos = Integer.parseInt(sanos[1]);
		for (int i = 0; i < nSanos; i++) {
			modelPersona s = new modelSano(app);
			personas.add(s);
			new Thread(s).start();
		}
		String[] infectados = datos[1].split(":",2);
		int nInfectados = Integer.parseInt(infectados[1]);
		for (int i = 0; i < nInfectados; i++) {
			modelPersona s = new modelInfectado(app);
			personas.add(s);
			new Thread(s).start();
		}
		String[] recuperados = datos[2].split(":",2);
		int nRecuperados = Integer.parseInt(recuperados[1]);
		for (int i = 0; i < nRecuperados; i++) {
			modelPersona s = new modelRecuperado(app);
			personas.add(s);
			new Thread(s).start();
		
		}
		System.out.println(personas.size());
	}

	public void pintar() {
		for (int i = 0; i < personas.size(); i++) {
			personas.get(i).pintar();
		}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				for (int i = 0; i < personas.size(); i++) {
					for (int j = 0; j < personas.size(); j++) {
						modelPersona a = personas.get(i);
						modelPersona b = personas.get(j);
						if (app.dist(a.getPosX(), a.getPosY(), b.getPosX(), b.getPosY())<a.getRadio()) {
							if (a instanceof modelInfectado && b instanceof modelSano) {
								int x = b.posX;
								int y = b.posX;
								b.setVivo(false);
								personas.remove(b);
								modelPersona c = new modelInfectado(app);
								c.setPosX(x);
								c.setPosY(y);
								personas.add(c);
								new Thread(c).start();
								break;
							} else if (b instanceof modelInfectado && a instanceof modelSano) {
								int x = a.posX;
								int y = a.posX;
								a.setVivo(false);
								personas.remove(a);
								modelPersona c = new modelInfectado(app);
								c.setPosX(x);
								c.setPosY(y);
								personas.add(c);
								new Thread(c).start();
								break;
							}
						}
					}
				}
				
				for (int i = 0; i < personas.size(); i++) {
					modelPersona a = personas.get(i);
					if (a.isVivo() == false) {
						int x = a.getPosX();
						int y = a.getPosY();
						personas.remove(a);
						modelPersona b = new modelRecuperado(app);
						b.setPosX(x);
						b.setPosY(y);
						personas.add(b);
						new Thread(b).start();
					}
				}
				
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
}