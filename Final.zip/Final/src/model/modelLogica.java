package model;

import java.util.ArrayList;

import processing.core.PApplet;

public class modelLogica implements Runnable{

	
}
