package model;

import processing.core.PApplet;

public class modelInfectado extends modelPersona {

	public modelInfectado(PApplet app) {
		super(app);
		Runnable curar =
			    new Runnable(){
			        public void run(){
			        	while (vivo) {
			    			try {
			    				Thread.sleep(14000);
			    				vivo=false;
			    			} catch (InterruptedException e) {
			    				e.printStackTrace();
			    			}
			    		}
			        }
			    };
			    
			    new Thread(curar).start();
	}

	@Override
	public void pintar() {
		app.fill(255,0,0,80);
		app.ellipse(posX, posY, radio*2, radio*2);
	}
	

}
