package model;

import processing.core.PApplet;

public class modelRecuperado extends modelPersona {

	public modelRecuperado(PApplet app) {
		super(app);
	}

	public void pintar() {
		app.fill(0,0,255,80);
		app.ellipse(posX, posY, radio*2, radio*2);
	}
}

