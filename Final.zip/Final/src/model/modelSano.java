package model;

import processing.core.PApplet;

public class modelSano extends modelPersona {

	public modelSano(PApplet app) {
		super(app);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void pintar() {
		// TODO Auto-generated method stub
		app.fill(0,255,0,80);
		app.ellipse(posX, posY, radio*2, radio*2);
	}

}
