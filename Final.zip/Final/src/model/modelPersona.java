package model;

import processing.core.PApplet;

public abstract class modelPersona implements Runnable{

	protected PApplet app;
	protected int posX;
	protected int posY;
	protected int velocidadX;
	protected int velocidadY;
	protected boolean vivo;
	protected int radio;
	
	public modelPersona(PApplet app) {
		// TODO Auto-generated constructor stub
		this.app = app;
		velocidadX = 3;
		velocidadY = 3;
		radio = 7;
		posX = (int) app.random(radio,app.width-radio);
		posY = (int) app.random(radio,app.height-radio);
		float r = app.random(0,1);
		if (r <= 0.5){
			velocidadX *= -1;
		}
		r = app.random(0,1);
		if (r <= 0.5){
			velocidadY *= -1;
		}
		vivo = true;
	}
	
	public abstract void pintar();
	
	@Override
	public void run() {
		while(vivo) {
			try {
				posX += velocidadX;
				posY += velocidadY;
				if (posX < radio || posX > app.width-radio) {
				velocidadX *= -1;
				}
				if (posY < radio || posY > app.height-radio) {
					velocidadY *= -1;
				}
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// TODO Auto-generated method stub
		}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public int getRadio() {
		return radio;
	}

	public void setRadio(int radio) {
		this.radio = radio;
	}

	public boolean isVivo() {
		return vivo;
	}

	public void setVivo(boolean vivo) {
		this.vivo = vivo;
	}
	
	
	
}