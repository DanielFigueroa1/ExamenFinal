package view;


import processing.core.PApplet;
import model.modelLogica;

public class Main extends PApplet {
	
	private modelLogica log;

	public static void main(String[] args) {
		PApplet.main("view.Main");
	}
	
	
	@Override
	public void settings() {
		size(600,400);
		
	}
	
	@Override
	public void setup() {
		log= new modelLogica(this);
		new Thread(log).start();
		noStroke();
		
	}
	
	@Override
	public void draw() {
		background(255);
		log.pintar();
	}
	
}